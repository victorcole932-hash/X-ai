# X AI — Full-stack starter

A deployable starter project based on the X AI interface. Includes:

- Responsive X AI web interface with six workspaces.
- Express backend and server-side OpenAI-compatible Chat Completions proxy.
- Email/password registration and login (scrypt password hashing; no plaintext passwords).
- SQLite-backed accounts, sessions and conversation storage.
- HTTP-only, same-site session cookie; rate limits; Helmet security headers; request-size limits.
- PWA manifest, SVG app icon and offline shell caching for installable mobile-web-app behavior.

## Requirements

- Node.js 20 or newer
- An AI provider account and API key for live AI responses (optional; demo UI works without one)

## Run locally

```bash
npm install
cp .env.example .env
```

Edit `.env` and set at minimum a long random `SESSION_SECRET`. For live model responses, set:

```env
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=your-provider-secret
AI_MODEL=gpt-4o-mini
AI_PROVIDER=OpenAI
```

Then start:

```bash
npm start
```

Open http://localhost:3000. Create an account using the **Sign in** button, then chat. The provider key stays on the server and is never sent to browser JavaScript.

For another OpenAI-compatible provider, set `AI_BASE_URL` to its API base URL and choose a model supported by that provider. The server appends `/chat/completions`.

## Install on Android / iPhone

Deploy the site over HTTPS, open it in Chrome (Android) or Safari (iOS), then use the browser's **Install app** / **Add to Home Screen** action. PWA installation is not the same as publishing a native app to Google Play or the Apple App Store.

## Deployment checklist

1. Use a hosting provider that supports Node.js and persistent disk storage for `data/`.
2. Set `NODE_ENV=production`, a unique `SESSION_SECRET` (32+ random characters), `AI_API_KEY`, `AI_MODEL`, and `AI_BASE_URL` as hosting environment secrets.
3. Enable HTTPS. Set `TRUST_PROXY=true` only when the app is behind a trusted reverse proxy that sets forwarded headers correctly.
4. Ensure `data/` is persistent and backed up; SQLite is suitable for a small single-instance launch, not a horizontally scaled multi-instance deployment.
5. Add transactional email, password reset, account verification, privacy/terms pages, abuse monitoring, backups and a managed database before public production use.
6. Configure billing/quotas and stronger abuse controls before allowing unrestricted public API usage.

## API endpoints

- `GET /api/health` — server and provider configuration status.
- `POST /api/auth/register` — `{ "email", "password" }`.
- `POST /api/auth/login` — `{ "email", "password" }`.
- `GET /api/auth/me` — current session user.
- `POST /api/auth/logout` — end session.
- `GET /api/conversations` — current user's saved conversations (auth required).
- `PUT /api/conversations/:id` — save a conversation (auth required).
- `POST /api/chat` — proxy a chat request to the configured AI provider (auth required).

## Current scope / honest limitations

- The backend currently proxies text chat only. The Image Studio creates prompts; Voice Lab uses browser text-to-speech; Video Studio creates storyboards. Actual image and video generation require provider-specific endpoints and often different billing/permissions.
- The PWA is installable from a secure origin, but it is not a native Android APK or iOS IPA and has not been submitted to app stores.
- The account system is a useful starter, not a finished identity platform: email verification, password reset, MFA, account deletion workflow, privacy/legal pages, and production-grade monitoring still need to be added.
- The app uses SQLite and is designed for a single Node instance with persistent storage. Use PostgreSQL or another managed database for multi-instance scale.
- Do not commit `.env`, API keys, database files, or session secrets to source control.
