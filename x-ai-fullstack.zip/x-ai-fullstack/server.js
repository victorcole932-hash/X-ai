import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import connectSqlite3 from 'connect-sqlite3';
import Database from 'better-sqlite3';
import { rateLimit } from 'express-rate-limit';
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const secret = process.env.SESSION_SECRET || '';
if (isProd && secret.length < 32) throw new Error('SESSION_SECRET must be at least 32 characters in production.');
if (!isProd && secret.length < 16) console.warn('WARNING: Set SESSION_SECRET in .env before deployment.');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);

const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'xai.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 password_salt TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS conversations (
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL,
 mode TEXT NOT NULL DEFAULT 'chat',
 messages_json TEXT NOT NULL DEFAULT '[]',
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const SQLiteStore = connectSqlite3(session);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(session({
 store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir, concurrentDB: true }),
 name: 'xai.sid', secret: secret || randomBytes(32).toString('hex'),
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false });
const chatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false });
const scrypt = promisify(scryptCallback);
const cleanEmail = v => String(v || '').trim().toLowerCase();
function requireAuth(req, res, next) { if (!req.session.userId) return res.status(401).json({ error: 'Please sign in to use the connected AI service.' }); next(); }
function validEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254; }
async function hashPassword(password, salt = randomBytes(16).toString('hex')) {
 const derived = await scrypt(password, salt, 64);
 return { salt, hash: Buffer.from(derived).toString('hex') };
}
function publicUser(id) { return db.prepare('SELECT id,email,created_at FROM users WHERE id=?').get(id) || null; }

app.get('/api/health', (_req, res) => res.json({ ok: true, providerConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL), provider: process.env.AI_PROVIDER || 'AI provider' }));
app.post('/api/auth/register', authLimiter, async (req, res) => {
 try {
  const email = cleanEmail(req.body?.email); const password = String(req.body?.password || '');
  if (!validEmail(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 200) return res.status(400).json({ error: 'Password must be 10–200 characters.' });
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({ error: 'An account with this email already exists.' });
  const { salt, hash } = await hashPassword(password);
  const result = db.prepare('INSERT INTO users(email,password_hash,password_salt) VALUES(?,?,?)').run(email, hash, salt);
  req.session.regenerate(err => { if (err) return res.status(500).json({ error: 'Could not create session.' }); req.session.userId = Number(result.lastInsertRowid); res.json({ user: publicUser(req.session.userId) }); });
 } catch (e) { console.error(e); res.status(500).json({ error: 'Account creation failed.' }); }
});
app.post('/api/auth/login', authLimiter, async (req, res) => {
 try {
  const email = cleanEmail(req.body?.email); const password = String(req.body?.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user) return res.status(401).json({ error: 'Email or password is incorrect.' });
  const { hash } = await hashPassword(password, user.password_salt);
  const a = Buffer.from(hash, 'hex'), b = Buffer.from(user.password_hash, 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(401).json({ error: 'Email or password is incorrect.' });
  req.session.regenerate(err => { if (err) return res.status(500).json({ error: 'Could not start session.' }); req.session.userId = user.id; res.json({ user: publicUser(user.id) }); });
 } catch (e) { console.error(e); res.status(500).json({ error: 'Sign-in failed.' }); }
});
app.get('/api/auth/me', (req, res) => res.json({ user: req.session.userId ? publicUser(req.session.userId) : null }));
app.post('/api/auth/logout', (req, res) => req.session.destroy(() => { res.clearCookie('xai.sid'); res.json({ ok: true }); }));

app.get('/api/conversations', requireAuth, (req, res) => {
 const rows = db.prepare('SELECT id,title,mode,messages_json,updated_at FROM conversations WHERE user_id=? ORDER BY updated_at DESC LIMIT 80').all(req.session.userId);
 res.json({ conversations: rows.map(r => ({ id:r.id,title:r.title,mode:r.mode,messages:JSON.parse(r.messages_json),updated:r.updated_at })) });
});
app.put('/api/conversations/:id', requireAuth, (req, res) => {
 const id = String(req.params.id || '').slice(0,80); const title = String(req.body?.title || 'New conversation').slice(0,120); const mode = String(req.body?.mode || 'chat').slice(0,24); const messages = req.body?.messages;
 if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id) || !Array.isArray(messages) || messages.length > 300) return res.status(400).json({ error: 'Invalid conversation payload.' });
 const safe = messages.map(m => ({ role: m?.role === 'user' ? 'user' : 'assistant', content: String(m?.content || '').slice(0,20000), at: Number(m?.at || Date.now()) }));
 db.prepare(`INSERT INTO conversations(id,user_id,title,mode,messages_json,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
 ON CONFLICT(id) DO UPDATE SET title=excluded.title,mode=excluded.mode,messages_json=excluded.messages_json,updated_at=CURRENT_TIMESTAMP WHERE conversations.user_id=excluded.user_id`).run(id,req.session.userId,title,mode,JSON.stringify(safe));
 res.json({ ok:true });
});
app.delete('/api/conversations/:id', requireAuth, (req,res) => { db.prepare('DELETE FROM conversations WHERE id=? AND user_id=?').run(req.params.id,req.session.userId); res.json({ok:true}); });

app.post('/api/chat', requireAuth, chatLimiter, async (req, res) => {
 try {
  const apiKey = process.env.AI_API_KEY; const model = process.env.AI_MODEL;
  if (!apiKey || !model) return res.status(503).json({ error: 'AI provider is not configured yet. Add AI_API_KEY and AI_MODEL to the server .env file.' });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 100) return res.status(400).json({ error: 'Provide between 1 and 100 messages.' });
  const safeMessages = messages.map(m => ({ role: m?.role === 'assistant' ? 'assistant' : 'user', content: String(m?.content || '').slice(0,20000) }));
  const base = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  const upstream = await fetch(`${base}/chat/completions`, { method:'POST', headers:{ 'Content-Type':'application/json', 'Authorization':`Bearer ${apiKey}` }, body:JSON.stringify({ model, messages:safeMessages, temperature:0.7 }), signal:AbortSignal.timeout(90000) });
  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok) { console.error('AI provider returned',upstream.status,data?.error?.message || ''); return res.status(502).json({ error: 'The AI provider request failed. Check your server provider settings.' }); }
  const content = data?.choices?.[0]?.message?.content;
  if (!content) return res.status(502).json({ error: 'The AI provider returned an unsupported response.' });
  res.json({ content: typeof content === 'string' ? content : JSON.stringify(content) });
 } catch (e) { console.error('AI request failed:',e.message); res.status(502).json({ error: e.name === 'TimeoutError' ? 'The AI provider timed out.' : 'Could not reach the AI provider.' }); }
});

app.use(express.static(path.join(__dirname, 'public'), { extensions:['html'] }));
app.get('*', (_req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT, () => console.log(`X AI is running at http://localhost:${PORT}`));
